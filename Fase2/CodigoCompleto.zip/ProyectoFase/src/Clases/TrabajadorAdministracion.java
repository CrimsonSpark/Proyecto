

package Clases;

import BD.*;

public class TrabajadorAdministracion extends Trabajador 
{
    Trabajador T;
    
     public void altaTrabajador(Trabajador t)
     {
        
        
     }
    
    public void bajaTrabajador(Trabajador t)
    {
        
        
    }
    
    public void modificar(Trabajador t)
    {
        
        
    }
    
}
